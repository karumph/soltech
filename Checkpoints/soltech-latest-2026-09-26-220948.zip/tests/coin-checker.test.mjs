import test from 'node:test';
import assert from 'node:assert/strict';
import {validMint,normalizeMarket,normalizeRisk,requestJSON,LookupError,createLookupSession,formatMoney} from '../dist/coin-checker-data.js';
const mint='So11111111111111111111111111111111111111112';
const other='FLUXBmPhT3Fd1EDVFdg46YREqHBeNypn1h4EbnTzWERX';
const pair='58oQChx4yWmvKdwLLZzBi4ChoCc2fqCUWBkwMihLYQo2';
const market=overrides=>({chainId:'solana',baseToken:{address:mint,name:'Wrapped SOL',symbol:'SOL'},quoteToken:{symbol:'USDC'},pairAddress:pair,priceUsd:'0.0123',marketCap:1000000,fdv:2000000,liquidity:{usd:5000},volume:{h24:30},priceChange:{h24:-2},txns:{h24:{buys:0,sells:1}},pairCreatedAt:1688106058000,...overrides});
const report=overrides=>({mint,tokenProgram:other,risks:[],token:{mintAuthority:null,freezeAuthority:null},tokenMeta:{mutable:true},...overrides});
test('Solana address validation checks base58 byte length, not only characters',()=>{
 for(const v of [mint,other,pair,'11111111111111111111111111111111'])assert.equal(validMint(v),true);
 for(const v of ['',null,'0x'+'1'.repeat(40),'Solana','1'.repeat(31),'1'.repeat(33),'z'.repeat(44),mint+' ',mint.replace('S','0')])assert.equal(validMint(v),false);
});
test('market selection requires exact chain/base token and chooses highest reported liquidity',()=>{
 const result=normalizeMarket([market({chainId:'ethereum',liquidity:{usd:1e12}}),market({baseToken:{address:other},quoteToken:{address:mint},liquidity:{usd:1e10}}),market({pairAddress:other,liquidity:{usd:80}}),market()],mint);
 assert.equal(result.pair,pair);assert.equal(result.pools,2);assert.equal(result.price,.0123);assert.equal(result.marketCap,1e6);assert.equal(result.fdv,2e6);assert.equal(result.buys,0);assert.equal(result.change,-2);
 assert.equal(normalizeMarket([market({baseToken:{address:other},quoteToken:{address:mint}})],mint),null);
});
test('absent or malformed market fields remain missing, never borrowed from FDV',()=>{
 const result=normalizeMarket([market({marketCap:null,liquidity:{usd:-3},priceUsd:'NaN',volume:{h24:'35'},txns:null,priceChange:{h24:Infinity},pairCreatedAt:1688106058})],mint);
 for(const key of ['marketCap','liquidity','price','volume','buys','sells','change','created'])assert.equal(result[key],null,key);
 assert.equal(result.fdv,2e6);
 assert.equal(normalizeMarket([market({pairCreatedAt:Date.now()+1e8})],mint).created,null);
 assert.equal(normalizeMarket([market({priceUsd:'0',marketCap:0})],mint).price,0);
 assert.throws(()=>normalizeMarket({error:'invalid'},mint),/format/);
});
test('risk reports preserve missing controls and reject mismatched identity',()=>{
 let r=normalizeRisk(report(),mint);assert.equal(r.level,'lower');assert.equal(r.mintAuthority,'Disabled');assert.equal(r.mutable,'Changeable');assert.equal(r.holders,null);
 r=normalizeRisk(report({token:{},tokenMeta:{}}),mint);assert.equal(r.mintAuthority,'Unavailable');assert.equal(r.freezeAuthority,'Unavailable');assert.equal(r.mutable,'Unavailable');
 assert.equal(normalizeRisk(report({token:{mintAuthority:other}}),mint).mintAuthority,'Enabled');
 for(const d of [null,{},report({mint:other}),report({risks:null}),report({tokenProgram:''})])assert.throws(()=>normalizeRisk(d,mint),/format/);
});
test('unclassified risk never becomes a green result and danger remains visible with incomplete checks',()=>{
 assert.equal(normalizeRisk(report({risks:[null]}),mint).level,'unknown');
 assert.equal(normalizeRisk(report({risks:[{name:'X',level:'info'}]}),mint).level,'unknown');
 assert.equal(normalizeRisk(report({risks:[{name:'Mutable',level:'warn'}]}),mint).level,'caution');
 const r=normalizeRisk(report({risks:[{name:'Known concern',level:'danger'},{}]}),mint);assert.equal(r.level,'high');assert.equal(r.incomplete,true);
 const mixed=normalizeRisk(report({risks:[{name:'Mutable',level:'warn'},{name:'Major',description:'Major reason',level:'danger'}]}),mint);assert.equal(mixed.flags[0].description,'Major reason');
});
test('tiny positive prices are not rounded to zero',()=>{
 assert.equal(formatMoney(1e-12),'$1.000e-12');assert.notEqual(formatMoney(.000002),'$0.00');assert.equal(formatMoney(0),'$0');assert.equal(formatMoney(null),'Unavailable');
});
test('network failures, HTTP limits, and invalid JSON produce deliberate error types',async()=>{
 for(const [status,code] of [[429,'rate'],[404,'missing'],[503,'service']])await assert.rejects(requestJSON('https://example.test',{fetcher:async()=>({ok:false,status})}),e=>e.code===code);
 await assert.rejects(requestJSON('https://example.test',{fetcher:async()=>({ok:true,text:async()=>'<html>'})}),e=>e.code==='format');
 await assert.rejects(requestJSON('https://example.test',{fetcher:async()=>{throw new TypeError('offline');}}),e=>e.code==='network');
 await assert.rejects(requestJSON('https://example.test',{timeout:2,fetcher:async(url,{signal})=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted'))))}),e=>e.code==='timeout');
 let options;assert.deepEqual(await requestJSON('https://example.test',{fetcher:async(url,o)=>{options=o;return {ok:true,text:async()=>'[]'};}}),[]);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
});
test('partial source failure keeps the successful source',async()=>{
 const changes=[],session=createLookupSession(s=>changes.push(s),{loadMarket:async()=>({name:'Real coin'}),loadRisk:async()=>{throw new LookupError('rate');}});
 await session.lookup(mint);const last=changes.at(-1);assert.equal(last.market.status,'ready');assert.equal(last.risk.status,'error');assert.match(last.risk.message,/Wait a minute/);
});
test('late responses from A cannot replace B even if the loader ignores abort',async()=>{
 const queued=[],changes=[];const loader=(mint,signal)=>new Promise(resolve=>queued.push({mint,resolve,signal}));
 const session=createLookupSession(s=>changes.push(s),{loadMarket:loader,loadRisk:loader});
 const a=session.lookup(mint),b=session.lookup(other);assert.equal(queued[0].signal.aborted,true);
 queued[2].resolve({name:'B market'});queued[3].resolve({name:'B risk'});await b;
 const count=changes.length;queued[0].resolve({name:'A'});queued[1].resolve({name:'A'});await a;
 assert.equal(changes.length,count);assert.equal(changes.at(-1).mint,other);assert.equal(changes.at(-1).market.data.name,'B market');
});
test('leaving the checker suppresses every pending response',async()=>{
 let finish;const changes=[],session=createLookupSession(s=>changes.push(s),{loadMarket:()=>new Promise(resolve=>finish=resolve),loadRisk:async()=>null});
 const pending=session.lookup(mint);session.dispose();const before=changes.length;finish({name:'Late'});await pending;assert.equal(changes.length,before);
});
test('invalid input cancels earlier work without starting network requests',async()=>{
 let finish,calls=0;const changes=[],session=createLookupSession(s=>changes.push(s),{loadMarket:()=>{calls++;return new Promise(resolve=>finish=resolve);},loadRisk:async()=>null});
 const pending=session.lookup(mint);await assert.rejects(session.lookup('bad'),/address/);const before=changes.length;finish({name:'Stale'});await pending;assert.equal(calls,1);assert.equal(changes.length,before);
});
