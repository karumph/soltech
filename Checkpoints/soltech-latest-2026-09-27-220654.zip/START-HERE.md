# Resume Soltech

Checkpoint: September 27, 2026. Live coin checking supports Solana, Ethereum, Base, BNB Chain, Polygon, Arbitrum, Avalanche and Optimism token addresses. Automated scanners remain UI previews; no live monitoring, account, wallet, payment, or trading integration.

Run `node mobile-preview.mjs` from this folder, then open [the fixed phone preview](http://127.0.0.1:4175/mobile-preview.html). If it already opens, leave that server running. The hosted Site may be older; this checkpoint has not been published.

The current design uses a white background, black text, silver glass controls, and blue/lilac categories. Faceted scanner marks echo the supplied logo, which is unchanged. Work mobile first.

- Check coin is the first screen. Paste a complete token address. Solana is recognized by its address format; 0x addresses require an explicit network choice. The bottom tabs are Check, Active, Find and Profile. Saved scanners and drafts are inside Profile, with existing Saved URLs preserved. Profile is local to this device; no account sync is connected.
- The checker shows price, market cap, liquidity, 1h/24h trading, pool age, total supply, reported holder accounts and concentration, token controls, project links and DEX paid status and active boost counts. Paid profiles and boosts stay separate from risk checks; omitted boost counts show Not reported, while failed or malformed checks stay Unavailable. Cancelled and pending profile orders have explicit labels. GeckoTerminal supplies minute and hourly price history with 1H, 6H, 1D, 1W and All controls. Short views use minute candles when available; controls without enough data or a distinct view are disabled. All is bounded available history, not lifetime history. Gaps are preserved, and recent ranges are anchored to lookup time. Price and clearly labeled estimated market cap are selectable. The estimate uses the current market-cap-to-price ratio, not recorded historical supply. Coin logos use provider images; missing images fall back to plain initials. Clear shares the address field’s outer border, reserves a fixed trailing space and is disabled when empty, so typing does not shrink the input. It cancels the lookup, resets results and returns focus. The report has Overview, Chart and Details tabs, with coin identity and risk summary outside them. Chart selection is retained when returning within the same tab. Unsupported ATH, fresh wallets and social age are explained under Sources & coverage. Last lookup stays only in the current tab until reload; scanner storage is unchanged.
- Active starts empty with Add scanner. Add opens Find, Saved, or Create.
- Find offers Public figure scanner and Early project scanner, with Create scanner at the top right using the existing draft-safe editor.
- A compact Deactivate button beside Edit moves a scanner into Saved without deleting it; Use scanner reactivates it. Using a scanner places it in Active and keeps it in Saved. Saved labels show In Active or Saved only. Drafts live only in Saved.
- The standalone Daily recap is removed. Active scanner cards show persistent unread sample-find counts. Opening a coin clears its New label only for that scanner.
- Each scanner shows sample findings for its current type, with coin summaries and matching context. High-risk samples are in Excluded; missing information remains Not assessed.
- Customize shows source choices first. Age & market, Trading activity, Risk & ownership, and public Post settings expand when needed. Captions update when edited. Choices persist; numeric and risk preferences do not filter the fixed samples yet.
- Public presets have no X accounts chosen. This is shown as unfinished setup, not connected monitoring.

Verified: 85 automated checks passed after the multichain checker, image, chart and copy updates. Live Solana and Base reports, chart dragging, keyboard scrubbing, range and metric selection, and Clear were checked in the phone preview; Ethereum market/security normalization was checked against real responses. See review/app-experience-review.md for this mobile redesign verification and limits, and review/coin-report-review.md for the underlying data integration record. Live browser lookups returned market and risk data for wrapped SOL and USDC, and a caution report with no indexed market for the official FLUX sample. Invalid-address correction, keyboard focus, compact phone layouts, and existing scanner navigation were checked. The following scanner walkthrough was also completed at the preceding checkpoint: Browser walkthrough covered first use, Add/Find/Use, findings, unread persistence, Saved status, editing/review/save, invalid-range recovery, and keyboard dialog dismissal/focus return. A 320px viewport, fixed 390px phone frame, and desktop were inspected. Core text/status color pairs exceed 4.5:1. Full screen-reader, real-device, reduced-motion emulation, and WCAG conformance audits were not performed. Motion and solid-background fallbacks remain in source.

Run checks: `node --test tests/*.test.mjs` and `node --check dist/app.js`. No installation or build is required.

User data is in browser storage, separately from these files. Keep the same browser and address. Different ports and the hosted Site have separate workspaces. The earlier `backups/current-draft.json` is only a reference snapshot, not a complete current export. Do not seed the user's workspace with QA data.

See `review/` for screenshots and the implementation review, and `research/` for sourced reports. The saved-folder checkpoint manifest verifies local file copies, not OneDrive cloud sync.




## Where we stopped tonight

The user is going to bed. Latest request: save everything so work can resume tomorrow. The professional chart refinement, compact Deactivate action, and finer minute-price integration are implemented. No additional features should be started without the next request.

The latest mobile QA lookup returned 348 minute observations for the supplied CopiumCat token: 1H showed 41 observations, 6H showed 270, and All showed 348. These are observations from that check, not fixed counts. Day/week were disabled because the returned history covered only about seven hours. Minute gaps stayed empty. Market-cap estimation and keyboard selection worked. Mobile and desktop screenshots are saved in review. All 85 automated checks and syntax checks passed.

Tomorrow: reopen the fixed phone preview, refresh to load the saved code, and review the finer chart with the user. A coin lookup can be rerun. Browser-local scanner records remain separate from the project ZIP; preserve this browser's site data and port. The hosted Site has not been updated. Minute history is cached source data from the last check, not continuous streaming. One-hour candles are the fallback when minute data is unavailable. No native-device or full screen-reader audit was performed.
Latest follow-up: charts now start in Market cap (est.) when valid price and market cap allow it. Price remains the fallback, and an explicit Price choice survives report-tab changes and reopening. Default chart-style discussion is still a proposal; candles have not been implemented. Browser check with the user's XPad lookup confirmed the default and Price choice retention. The 11 chart tests and syntax check passed after this change.
