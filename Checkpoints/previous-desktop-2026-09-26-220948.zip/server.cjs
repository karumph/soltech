const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const page = path.join(__dirname, 'dist', 'index.html');
http.createServer((req, res) => {
  if (req.url !== '/' && req.url !== '/index.html') {
    res.writeHead(404).end('Not found');
    return;
  }
  fs.readFile(page, (error, content) => {
    if (error) { res.writeHead(500).end('Unable to read preview'); return; }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(content);
  });
}).listen(4173, '127.0.0.1', () => console.log('SolTech preview: http://127.0.0.1:4173'));
