# Soltech silver identity — September 29, 2026

## Direction

A separate comparison derived from the existing app. The unchanged dual-profile logo supplies contrast, connected forms and a small paired edge detail. Its faces and facets are not repeated as decoration across the interface.

The user's latest preference is silver rather than blue selection styling. Navigation and report controls use a silver moving highlight without a blue underline. Primary actions use a charcoal metallic fill; reading surfaces remain white. Personal avatar choices and meaningful warning/status colors retain their separate purpose.

## Shared rules

- White reading surfaces, charcoal text, cool gray dividers and restrained silver reflections.
- Clear system typography, deliberate spacing and moderate rounding; large headings identify the task, smaller labels organize evidence.
- Use a paired charcoal/silver seam sparingly on important identity and input areas.
- Keep input boundaries and keyboard focus visible. Errors restore a distinct red field boundary. Use text with all status colors.
- Navigation remains familiar. Motion belongs to selection and feedback, with reduced-motion, reduced-transparency and forced-color fallbacks.
- Choose layout by content: a coin report uses a metric ledger and disclosure sections; Scanner uses an identity row and rule list; Profile uses compact identity and shortcuts.
- Preserve established accessible labels, form hooks, validation, stored settings and cancellation behavior.

The final implementation is `dist/soltech-identity.css`, loaded after existing component styles. The earlier blue-glass stylesheet remains in the source for inherited layout and behavior; the final layer defines this comparison's look.

## Verification

- 152 automated tests passed, covering the existing data, storage, scanner, profile, crop and integration behavior. Later silver changes were CSS-only.
- Live Wrapped SOL lookup returned market and risk information; missing market cap remained unavailable, and an unconnected bundle service remained clearly marked.
- Overview / Chart / Details navigation, one-hour minute history, keyboard scrubbing, Clear and invalid-address feedback were checked in the rendered app.
- Profile Cancel retained the saved identity. Notification Save returned to Profile or Settings according to its entry route. About opened and dismissed with Escape.
- Combined scanner setup reached Review with both source rules. Save draft & exit, refresh and Continue restored the same unfinished source step. Save setup succeeded without implying live monitoring.
- Mobile frame and desktop were visually inspected. At 320px, Check, Scanner and Profile had no horizontal overflow. Control boundaries, focus and invalid styling were inspected.
- The original's 162 recorded files matched their SHA-256 baseline; the supplied logo is unchanged.

This was not a complete screen-reader or WCAG conformance audit, a physical iPhone test, or a native Liquid Glass implementation. The chart shows fetched history, not a continuous live stream. Scanner monitoring and alerts remain unconnected. No financial performance or risk-detection accuracy is inferred from visual polish.

## Files and follow-up

Current visual screenshots: `design-review/desktop-check-silver.png`, `design-review/mobile-check-silver.png`, `design-review/mobile-scanner-silver.png`, `design-review/mobile-profile-silver.png`. Other dated images are development history.

Compare this version with the original before choosing which to advance. Do not deploy using the inherited hosting identity. Browser-local user data is separate from the source backup, and comparison storage is isolated by port 4183.
