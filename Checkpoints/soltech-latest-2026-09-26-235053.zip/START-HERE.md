# Resume Soltech

Checkpoint: September 26, 2026. Live coin checking supports Solana, Ethereum, Base, BNB Chain, Polygon, Arbitrum, Avalanche and Optimism token addresses. Automated scanners remain UI previews; no live monitoring, account, wallet, payment, or trading integration.

Run `node mobile-preview.mjs` from this folder, then open [the fixed phone preview](http://127.0.0.1:4175/mobile-preview.html). If it already opens, leave that server running. The hosted Site may be older; this checkpoint has not been published.

The current design uses a white background, black text, silver glass controls, and blue/lilac categories. Faceted scanner marks echo the supplied logo, which is unchanged. Work mobile first.

- Check coin is the first screen. Paste a complete token address. Solana is recognized by its address format; 0x addresses require an explicit network choice. The bottom tabs are Check, Active, Find and Profile. Saved scanners and drafts are inside Profile, with existing Saved URLs preserved. Profile is local to this device; no account sync is connected.
- The checker shows price, market cap, liquidity, 1h/24h trading, pool age, total supply, reported holder accounts and concentration, token controls, project links and DEX paid status and active boost counts. Paid profiles and boosts stay separate from risk checks; omitted boost counts show Not reported, while failed or malformed checks stay Unavailable. Cancelled and pending profile orders have explicit labels. GeckoTerminal supplies an interactive hourly price chart with drag/keyboard scrubbing and day/week/all ranges when available. Price and clearly labeled estimated market cap are selectable. The estimate uses the current market-cap-to-price ratio, not recorded historical supply. Coin logos use provider images; missing images fall back to plain initials. A separate Clear button beside the input cancels the lookup, resets results and returns focus. The report has Overview, Chart and Details tabs, with coin identity and risk summary outside them. Chart selection is retained when returning within the same tab. Unsupported ATH, fresh wallets and social age are explained under Sources & coverage. Last lookup stays only in the current tab until reload; scanner storage is unchanged.
- Active starts empty with Add scanner. Add opens Find, Saved, or Create.
- Find offers Public figure scanner and Early project scanner.
- Using a scanner places it in Active and keeps it in Saved. Saved labels show In Active or Saved only. Drafts live only in Saved.
- The standalone Daily recap is removed. Active scanner cards show persistent unread sample-find counts. Opening a coin clears its New label only for that scanner.
- Each scanner shows sample findings for its current type, with coin summaries and matching context. High-risk samples are in Excluded; missing information remains Not assessed.
- Customize shows source choices first. Age & market, Trading activity, Risk & ownership, and public Post settings expand when needed. Captions update when edited. Choices persist; numeric and risk preferences do not filter the fixed samples yet.
- Public presets have no X accounts chosen. This is shown as unfinished setup, not connected monitoring.

Verified: 75 automated checks passed after the multichain checker, image, chart and copy updates. Live Solana and Base reports, chart dragging, keyboard scrubbing, range and metric selection, and Clear were checked in the phone preview; Ethereum market/security normalization was checked against real responses. See review/app-experience-review.md for this mobile redesign verification and limits, and review/coin-report-review.md for the underlying data integration record. Live browser lookups returned market and risk data for wrapped SOL and USDC, and a caution report with no indexed market for the official FLUX sample. Invalid-address correction, keyboard focus, compact phone layouts, and existing scanner navigation were checked. The following scanner walkthrough was also completed at the preceding checkpoint: Browser walkthrough covered first use, Add/Find/Use, findings, unread persistence, Saved status, editing/review/save, invalid-range recovery, and keyboard dialog dismissal/focus return. A 320px viewport, fixed 390px phone frame, and desktop were inspected. Core text/status color pairs exceed 4.5:1. Full screen-reader, real-device, reduced-motion emulation, and WCAG conformance audits were not performed. Motion and solid-background fallbacks remain in source.

Run checks: `node --test tests/*.test.mjs` and `node --check dist/app.js`. No installation or build is required.

User data is in browser storage, separately from these files. Keep the same browser and address. Different ports and the hosted Site have separate workspaces. The earlier `backups/current-draft.json` is only a reference snapshot, not a complete current export. Do not seed the user's workspace with QA data.

See `review/` for screenshots and the implementation review, and `research/` for sourced reports. The saved-folder checkpoint manifest verifies local file copies, not OneDrive cloud sync.



