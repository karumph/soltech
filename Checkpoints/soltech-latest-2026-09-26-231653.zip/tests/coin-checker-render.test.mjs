import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeRisk} from '../dist/coin-checker-data.js';
import {resultHTML} from '../dist/coin-checker.js';
const mint='So11111111111111111111111111111111111111112';
const report=overrides=>normalizeRisk({mint,tokenProgram:'Token',risks:[],token:{supply:1,decimals:9,mintAuthority:null,freezeAuthority:null},...overrides},mint);
const state=risk=>({mint,market:{status:'empty'},risk,listing:{status:'ready',data:{profilePaid:true,retrievedAt:1}}});

test('a positive fractional total supply never renders as zero',()=>{
 const html=resultHTML(state({status:'ready',data:report()}));
 assert.match(html,/<dt>Total supply<\/dt><dd class="">1\.000e-9<\/dd>/);
 assert.match(html,/0\.000000001/);
});
test('unavailable risk stays unassessed even with an approved paid profile',()=>{
 const html=resultHTML(state({status:'error',message:'Unavailable'}));
 assert.match(html,/Not assessed/);assert.match(html,/Approved paid profile/);assert.doesNotMatch(html,/risk lower|No flags reported/);
});
test('a report preserves the most serious warning and escapes source content',()=>{
 const html=resultHTML(state({status:'ready',data:report({tokenMeta:{name:'<img src=x onerror=alert(1)>'},risks:[{name:'Mutable',level:'warn'},{name:'Freeze enabled',description:'<script>bad</script>',level:'danger'}]})}));
 assert.match(html,/quick-risk high/);assert.match(html,/High risk reported/);assert.match(html,/Freeze enabled/);
 assert.doesNotMatch(html,/<img|<script/);assert.match(html,/&lt;script&gt;/);
});
