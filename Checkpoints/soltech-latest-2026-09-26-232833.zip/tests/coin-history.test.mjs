import test from 'node:test';
import assert from 'node:assert/strict';
import {historyWindow,nearestPoint,historyHTML,marketCapFactor} from '../dist/coin-history.js';
const hour=3600000;
const points=[0,1,2,30,60,190].map(n=>({timestamp:1800000000000+n*hour,close:1+n/100}));
const h={points,from:points[0].timestamp,through:points.at(-1).timestamp,observedHigh:3,pair:'pool'};
test('market-cap estimates require finite positive current data and remain explicitly estimates',()=>{
 assert.equal(marketCapFactor({marketCap:100000,price:.01}),10000000);
 for(const market of [{marketCap:null,price:.01},{marketCap:1,price:0},{marketCap:Infinity,price:1},{marketCap:1e308,price:1e-100}])assert.equal(marketCapFactor(market),null);
 assert.equal(marketCapFactor({marketCap:1e308,price:1},h),null);
 assert.match(historyHTML({status:'ready',data:h},{marketCap:100000,price:.01}),/Market cap \(est\.\)/);
 assert.match(historyHTML({status:'ready',data:h},{}),/value="cap" disabled/);
});
test('chart ranges preserve real timestamps and choose an actual candle across missing hours',()=>{
 assert.deepEqual(historyWindow(h,'day'),[points[5]]);
 assert.deepEqual(historyWindow(h,'week'),points.slice(3));
 assert.deepEqual(historyWindow(h,'all'),points);
 assert.equal(nearestPoint(points,points[0].timestamp+25*hour),3);
 assert.equal(nearestPoint(points,-Infinity),0);
});
test('chart presents current market cap separately from historical close and preserves missing cap',()=>{
 const html=historyHTML({status:'ready',data:h},{marketCap:250000,retrievedAt:1800000000000});
 assert.match(html,/Current market cap/);assert.match(html,/\$250K/);assert.match(html,/Selected close/);assert.match(html,/Historical market cap is unavailable/);
 assert.match(html,/type="range"/);assert.match(html,/data-history-range="week"/);
 assert.match(historyHTML({status:'ready',data:h},{marketCap:null}),/Current market cap<\/span><strong>Unavailable/);
});
